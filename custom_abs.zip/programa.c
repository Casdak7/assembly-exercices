#include <stdio.h>

extern int custom_abs(int num);

int main(){
    int b = custom_abs(-5);   
    printf("%d\n", b);
    b = custom_abs(3);   
    printf("%d\n", b);
    b = custom_abs(7);   
    printf("%d\n", b);
    b = custom_abs(-45);   
    printf("%d\n", b);

    return 0;
}